# OPEN_POINTS

| ID | Question / 不明点 | Affected files/sections | Proposed safe interim behavior | Notes |
|----|--------------------|-------------------------|---------------------------------|-------|
| OP-001 | Should `confidence_level` be exposed in API v1? | doc/06_API_DESIGN_DETAILED.md, src/... | Keep internal only; default 0.95; no API field | To be decided by PO |
